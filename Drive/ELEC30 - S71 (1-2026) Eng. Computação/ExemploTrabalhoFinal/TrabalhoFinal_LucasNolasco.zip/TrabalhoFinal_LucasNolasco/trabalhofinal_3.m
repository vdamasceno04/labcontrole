clear all; clc;

s = tf('s');

G = (4*s+1)/(s*(s+1)*(0.4*s+1));

T = 0.2; % Período de amostragem
Gz = c2d(G, T, 'zoh'); % Amostra o sistema

Gw = d2c(Gz,'tutsim'); % Leva o sistema para o domínio da transformada bilinear

K = 10.0402; % Ganho para atingir o erro à rampa desejado

Gwcg = 22.2; % Ganho na nova frequência de cruzamento de ganho
wcg = 2.18; % Nova frequência de cruzamento de ganho

alpha = 10^(Gwcg/20);
tau = 1/(0.1*wcg);

z = tf('z', T);

Dw = K*((tau*s + 1)/(alpha*tau*s + 1)); % Calcula o controlador no domínio da transformada bilinear

Dz = K*((tau*(2/T)*(z-1)/(z+1) + 1)/(alpha*tau*(2/T)*(z-1)/(z+1) + 1)); % Calcula o controlador no domínio z
Dz = minreal(Dz);

fprintf("Frequência do pico de ressonância: %f rad/s", getPeakGain(feedback(Gz*Dz,1))); % Obtém a frequência do pico de ressonância

figure; margin(Gz*Dz); % Plota o diagrama de Bode para o sistema controlado
figure; step(feedback(Gz*Dz,1)); % Plota a resposta ao degrua para o sistema controlado

t = 0:T:100;
lsim(feedback(Gz*Dz,1), t, t); % Plota a resposta à rampa para conferir o erro