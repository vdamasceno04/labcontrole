clear all; clc;

s = tf('s');

G = (4*s+1)/(s*(s+1)*(0.4*s+1));

figure; step(feedback(c2d(G, 1.134, 'zoh'), 1)); % Plota o sistema discretizado antes de perder a estabilidade
figure; step(feedback(c2d(G, 1.135, 'zoh'), 1)); % Plota o sistema discretizado depois de perder a estabilidade

T1 = 1.134; % Período máximo de amostragem para a estabilidade 
T2 = 0.1827; % Período máximo para ter ao menos 10 amostras por ciclo

Gz1 = c2d(G, T1, 'zoh');
Gz2 = c2d(G, T2, 'zoh');

figure;rlocus(Gz1);
figure;rlocus(Gz2);

figure; margin(Gz1 * 10);
figure; margin(Gz2 * 10);