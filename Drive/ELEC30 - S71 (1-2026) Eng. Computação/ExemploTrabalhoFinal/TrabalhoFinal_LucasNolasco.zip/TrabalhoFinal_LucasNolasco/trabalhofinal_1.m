clear all; clc;

s = tf('s');

G = (4*s+1)/(s*(s+1)*(0.4*s+1));

rlocus(G); % Plota o diagrama de lugar das raízes

K = 10; % Ganho para atingir a especificação de erro de regime

FTMF = feedback(G*K,1); % Fecha a malha com o ganho calculado

zero(FTMF) % Verifica os zeros do sistema em malha fechada
pole(FTMF) % Verifica os polos do sistema em malha fechada

stepinfo(FTMF); % Verifica tempo de subida, tempo de acomodação, tempo de pico e sobressinal
step(FTMF); % Plota a resposta ao degrau

t = 0:0.1:100;
figure; lsim(FTMF, t, t); % Plota a resposta à rampa para verificar se o erro à rampa está correto

figure; margin(G); % Plota os diagramas de Bode para o sistema original
figure; margin(G*K); % Plota os diagramas de Bode para o sistema controlado