clear all; clc;

s = tf('s');

G = (4*s+1)/(s*(s+1)*(0.4*s+1));

K = 10.0402; % Ganho para atingir o erro à rampa especificado

T = 0.2; % Período de amostragem
Gz = c2d(G, T, 'zoh'); % Amostra o sistema

damp(feedback(G*K,1)); % Para encontrar a frequência natural do sistema

wn = 1.01; % Frequência natural do sistema em malha fechada com ganho K

Ku = K; % Usando o ganho para atingir o erro de regime como K crítico
Tu = 2*pi/wn; % Usando como período crítico o período da frequência natural do sistema com esse K

Kp = 0.6 * Ku;
Ti = 0.5 * Tu;
Td = 0.125 * Tu;

Ds = pid(Kp, Kp/Ti, Kp*Td);
Dz = pid(Kp, Kp/Ti, Kp*Td, 0, T); % Cria o controlador PID

step(feedback(Gz*Dz,1));

%%%% RECALCULA O CONTROLADOR DE ATRASO DE FASE PARA PLOTAR A COMPARAÇÃO
%%%% ENTRE ELES

Gwcg = 22.2; % Ganho na nova frequência de cruzamento de ganho
wcg = 2.18; % Nova frequência de cruzamento de ganho

alpha = 10^(Gwcg/20);
tau = 1/(0.1*wcg);

z = tf('z', T);
Dz_atraso = K*((tau*(2/T)*(z-1)/(z+1) + 1)/(alpha*tau*(2/T)*(z-1)/(z+1) + 1)); % Calcula o controlador no domínio z
Dz_atraso = minreal(Dz_atraso);

stepplot(feedback(Gz*Dz_atraso,1), feedback(Gz*Dz, 1)); % Plota a resposta ao degrau do atraso de fase junto da resposta do PID
legend('Atraso de Fase', 'PID');